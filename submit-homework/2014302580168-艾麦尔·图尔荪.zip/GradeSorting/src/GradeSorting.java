import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import jxl.JXLException;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class GradeSorting {

	
	public static String grade[][] = new String[22][10] ;  //���ڸĽ�ֱ���ڹ��캯�����壬�����ȶ����С
    public static String gpa;
    public static String averageMark;
	public GradeSorting() {
		// TODO Auto-generated constructor stub
		//String grade[][] = new String[allRec][row];
	}
	//��ȡ�ɼ�
	public  void getGrade() throws BiffException, IOException {
		File file = new File ("F:/workspace/GradeSorting/test.xls"); 
		InputStream in = new FileInputStream(file); 
		 jxl.Workbook wb = Workbook.getWorkbook(in);
	      jxl.Sheet sheet = wb.getSheet(0);
		 int allRec = sheet.getRows();	//��ȡ����
			int row = sheet.getColumns();//��ȡsheet����
		 for(int i =0;i<allRec;i++){
			 for(int j=0;j<row;j++){
				 jxl.Cell cells = sheet.getCell(j,i );
				grade[i][j]=cells.getContents();
	    	      
			 	}
			 
		 	}
		 }
		
	
			
	//����
      public void Sort( String[][]grade) {
		
		for (int j = 0; j < grade.length ; j++) {
			for (int i = 0; i < grade.length - 1; i++) {
				String[] ss;
				if (grade[i][9].compareTo(grade[i + 1][9]) <0) {
					ss = grade[i];
					grade[i] = grade[i + 1];
					grade[i + 1] = ss;
					
				}
			}
		}
	}
      
      //�鿴Ч��
      public void output(String[][]grade,String gpa,String averageMark ) throws IOException, RowsExceededException, WriteException  {
  		WritableWorkbook book = Workbook.createWorkbook(new File("Aftersorting.xls"));
  		WritableSheet sheet=book.createSheet("��һҳ", 0) ;
  		for (int i = 0; i < grade.length; i++) {
  			for (int j = 0; j < grade[i].length; j++) {
  					Label label=new Label(j,i,grade[i][j]);
  					sheet.addCell(label);
  					
  					
  			}
  			
  		}
  			Label label=new Label(0,22,"���㣺");
			sheet.addCell(label);
			Label label1=new Label(1,22,gpa);
			sheet.addCell(label1);
			Label label2=new Label(0,23,"��Ȩƽ���֣�");
			sheet.addCell(label2);
			Label label3=new Label(1,23,averageMark);
			sheet.addCell(label3);
  		book.write();
			book.close();
  		
      }
     
  public void Gpa(String[][]grade){
	  double t=0;//��Ȩƽ����
	  double n =0;//ѧ�ֺ�
	  double k=0;//�ɼ���ѧ�ֳ˻�
	  double j=0;
	  double l=0;
		double[]Gpa=new double[22];
	  double []creditPoint = new double[22];
	  double[]Grade =new double[22] ;
	  for(int i =0; i<22;i++){
		  
		  creditPoint[i]= Double.parseDouble(grade[i][3]);  
		  Grade[i]= Double.parseDouble(grade[i][9]);  
		
		if(Grade[i]>=90&&Grade[i]<=100)
			  Gpa[i]=4.0;
		  else if (Grade[i]>=85&&Grade[i]<=89)
			  Gpa[i]=3.7;
		  else if (Grade[i]>=82&&Grade[i]<=84)
			  Gpa[i]=3.3;
		  else if (Grade[i]>=78&&Grade[i]<=81)
			  Gpa[i]=3.0;
		  else if (Grade[i]>=75&&Grade[i]<=77)
			  Gpa[i]=2.7;
		  else if (Grade[i]>=72&&Grade[i]<=74)
			  Gpa[i]=2.3;
		  else if (Grade[i]>=68&&Grade[i]<=71)
			  Gpa[i]=2.0;
		  else if (Grade[i]>=64&&Grade[i]<=67)
			  Gpa[i]=1.5;
		  else if (Grade[i]>=60&&Grade[i]<=63)
			  Gpa[i]=1.0;
		  else 
			  Gpa[i]=0.0;
		  n+= creditPoint[i];
		  k+=creditPoint[i]* Grade[i];
		  t=k/n;//��Ȩƽ����
		  j+=creditPoint[i]* Gpa[i];
		  l=j/n;  
	  }
	System.out.println(t+"  "+l);
	  gpa=String.valueOf(l);
	  averageMark=String.valueOf(t);
	  System.out.println(gpa+"  "+averageMark);
  }
  public static void run() throws BiffException, IOException, RowsExceededException, WriteException{
	  
	  GradeSorting my=	 new GradeSorting();
	  my.getGrade();
	  my.Sort(grade);
	  my.Gpa(grade);
	  my.output(grade,gpa,averageMark);
	  
	  
  }
      
      public static void main(String[] args) throws BiffException, IOException, RowsExceededException, JXLException {
		// TODO Auto-generated method stub
    	
         run();
}
}
		
	


