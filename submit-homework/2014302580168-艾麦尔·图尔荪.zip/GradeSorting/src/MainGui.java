import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;

import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class  MainGui extends JFrame implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	MainGui(){
		
		new JFrame ("�ɼ�����");
		setSize(200, 300);
		JButton Start =	new JButton("�����ʼ����");
		add(Start);
		Start.addActionListener(this);
		
		setVisible(true);
		
		
	}


	public static void main(String[] args)   {
		// TODO Auto-generated method stub
		new MainGui();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		 
	}
	
}
